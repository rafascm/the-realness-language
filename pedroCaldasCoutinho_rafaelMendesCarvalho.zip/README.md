# ufrj-compiladores
### The Realness Language
Just another very fishy language to y'all

Stay Foxy , UON UON :p

 - How does it work?
    - open and close known **{}** are **\<shantay u stay> \</sashay away>**.
    - the commands **if**, **else**, **while**, **do while** and **for** have the same syntax as C language.
    - the **.roo** files have to start with:
      *The library is officially open
      because reading is? FUNDAMENTAL;*
    - and end it with:
      *The library is officially closed;*
    - the operator **@** compares arrays to see if they are equal or not, returning **1** if they are and **0** if they aren't.
    - the operators **!= < > ==** are defined for strings as well. It is also possible to concat strings using the operator **+**.
    - the operator **in** is defined only when the *var* in the right is an array, uni or bidimensional.
    - the commands known as **readU** and **wroteU** are the ***The Realness*** version of cin/cout


##### Para alterar os arquivos *.roo* compilados, altere o makefile linhas 1 e 2 substituindo os .roo pelo desejado

by Pedro Caldas Coutinho and Rafael Mendes de Carvalho

#### This language was inspired by the slangs used on RuPaul's Drag Race
